# Ransomware-Builder-V.2.0
Ransomware Builder V.2.0
 
 
if you are using this program, you accept all responsibility. Only for educational purposes.
![ss](https://user-images.githubusercontent.com/83380140/174143204-5ca1ace4-906c-4d83-ae67-1a11215585a5.jpg)

his is a ransomware builder V2.0 , which allows you to encrypt your files in case of emergency
or something like this , this gives the encrypted device a unquie ID , and files must be recoved on same infected windows machine and also without changing user on that machine.

By pressing on decrypt files will open the decrypter which will be required to enter first the files extensions and


please follow these steps LETTERLY to get a successful decryption in case if you need to retrieve files from the builder program you have built yourself


STEPS :
1- press decrypt files to show up the decrypter .
2- open task manager and startup and delete the ransomware and each "exe" file in the startup folder .
3- search for a process which description is called "csrss" NOT PROCESS NAME , JUST DESCRIPTION and then end it , NOT end Tree in order not to close Decrypter .
4- search for a process which name is called "DECRYPT.exe" which is the GUI , then end it , NOT TREE too
5- inside Decrypter form , { Enter name of extension } that you have choose before while building your program , then press {ENTER key}
then enter the key which will be provided within the Key Generator, then if the key is true will launch "Fixed file" then enjoy successful decrypt process for all of files
![67148190-4f91ed80-f2a5-11e9-9115-e65e23e33f87](https://user-images.githubusercontent.com/83380140/174143222-b7fbad21-e807-4d0a-b569-9225360281d2.png)
